package com.yodlee.engg.utility;

import com.yodlee.engg.dao.Yodlee_User_Manager;
import com.yodlee.engg.models.Yodlee_User;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Yodlee_User user =new Yodlee_User();
		//user.setName("Parameswari");
		//user.setPassword("viki");
		
		//System.out.println(Yodlee_User_Manager.addUser(user)); 
		
		for(Yodlee_User user : Yodlee_User_Manager.getAllUsers())
		{
			System.out.println(user.getName());
			System.out.println(user.getPassword());
			
		}
		
	}

}
