package com.continental.utility;

import java.util.Random;

public class ThreadLocalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadLocalFormatter obj = new ThreadLocalFormatter();
        for(int i=0 ; i<10; i++){
            Thread t = new Thread(obj, ""+i);
            try {
				Thread.sleep(new Random().nextInt(1000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            t.start();
	}
	}

}
