package com.continental.atomics;



public class AtomicTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable runnable=()->{
			
			try {
				
				System.out.println(new DataDefiner().increment() +"updated by ---->"+ Thread.currentThread().getName());
				Thread.sleep(1000);
				System.out.println("Decrementing.....");
				System.out.println(new DataDefiner().decrement() +"updated by ---->"+ Thread.currentThread().getName());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		};
		
		Thread t1 =new Thread(runnable,"T1");
		Thread t2 =new Thread(runnable,"T2");
		Thread t3 =new Thread(runnable,"T3");
		Thread t4 =new Thread(runnable,"T4");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		

	}

}
