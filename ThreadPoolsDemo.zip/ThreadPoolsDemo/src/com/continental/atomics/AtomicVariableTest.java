package com.continental.atomics;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicVariableTest {
	private static  Integer integer = new Integer(0);
	private static  AtomicInteger atomicInteger = new AtomicInteger(0);
	
		static class IntegerIncrementer extends Thread {
		public void run() {
		++integer;
		}
		}
		static class AtomicIntegerIncrementer extends Thread {
		public void run() {
		atomicInteger.incrementAndGet();
		}
		}
		public static void main(String []args) {
		// create three threads each for incrementing atomic and "normal" integers
		for(int i = 0; i < 10; i++) {
		new IntegerIncrementer().start();
		new AtomicIntegerIncrementer().start();
		System.out.printf("final int value = %d and final AtomicInteger value = %d\n",
				integer, atomicInteger.intValue());
		}
		
		}

	

}
