package com.continental.atomics;

import java.util.concurrent.atomic.AtomicInteger;

public class DataDefiner {

	private static final AtomicInteger atomic=new AtomicInteger(200);
	
	
	
	
	public Integer increment()
	{
		return atomic.incrementAndGet();
	}
	
	public Integer decrement()
	{
		return atomic.decrementAndGet();
	}
	
}
