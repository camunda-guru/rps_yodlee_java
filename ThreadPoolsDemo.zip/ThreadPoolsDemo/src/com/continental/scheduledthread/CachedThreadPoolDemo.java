package com.continental.scheduledthread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CachedThreadPoolDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create an executor with a cached thread pool to execute 4 clocks concurrently. 
		//creates thread as and when required or task increases
		// Idle threads are kept in the pool for one minute.
		ExecutorService pool = Executors.newCachedThreadPool();
		 
        pool.execute(new CountDownClock("A"));
        pool.execute(new CountDownClock("B"));
        pool.execute(new CountDownClock("C"));
        pool.execute(new CountDownClock("D"));
        pool.execute(new CountDownClock("E"));
        pool.execute(new CountDownClock("F"));
        pool.execute(new CountDownClock("G"));
        pool.shutdown();
	}

	
	
	
}
