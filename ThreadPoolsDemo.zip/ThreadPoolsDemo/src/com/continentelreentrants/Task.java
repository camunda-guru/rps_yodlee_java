package com.continentelreentrants;

public interface Task {
	public void performTask();
}
