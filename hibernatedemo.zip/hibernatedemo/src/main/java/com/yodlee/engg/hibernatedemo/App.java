package com.yodlee.engg.hibernatedemo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.yodlee.engg.helpers.FactoryHelper;
import com.yodlee.engg.models.Yodlee_Employee;
import com.yodlee.engg.models.Yodlee_Event;


public class App 
{
	
	public static void addEmployees(Yodlee_Event  event)
	{
		
		Session session = FactoryHelper.getConnection().openSession();
		
        Transaction transaction=session.beginTransaction();        
        try
        {
         session.save(event);
        transaction.commit();
        }
        catch(HibernateException hib)
        {
        	transaction.rollback();
        }
        finally
        {
        	session.close();
        }
		
	}
	
	
	public static void addEvent(Yodlee_Event event)
	{
		 Session session = FactoryHelper.getConnection().openSession();
	        Transaction transaction=session.beginTransaction();
	        
	        try
	        {
	        session.save(event);
	        transaction.commit();
	        }
	        catch(HibernateException hib)
	        {
	        	transaction.rollback();
	        }
	        finally
	        {
	        	session.close();
	        }
	        
	}
	
	public static Yodlee_Event getEventById(int id)
	{
		 Session session = FactoryHelper.getConnection().openSession();
		 
		   Yodlee_Event evnt= (Yodlee_Event) session.get(Yodlee_Event.class, id);
		   return evnt;
		
		
	}
	
	public static void updateEvent(Date date,int id)
	{
		
		Session session = FactoryHelper.getConnection().openSession();
		Yodlee_Event evnt= (Yodlee_Event) session.get(Yodlee_Event.class, id);
		evnt.setEventDate(date);
		 Transaction transaction=session.beginTransaction();
		 try
		 {
		 session.update(evnt);
		 transaction.commit();
		 }
		 catch(HibernateException hib)
		 {
			 transaction.rollback();
		 }
		
	}
	
	public static void detachedObject()
	{
		Session session = FactoryHelper.getConnection().openSession();
		Yodlee_Event evnt1= (Yodlee_Event) session.get(Yodlee_Event.class, 1);
		Yodlee_Event evnt2= (Yodlee_Event) session.get(Yodlee_Event.class, 2);
		 Transaction transaction=session.beginTransaction();
		session.evict(evnt2);// detaching the object
		evnt1.setLocation("Chennai");
		evnt2.setLocation("Mumbai");
		session.getTransaction().commit();
		
	}
	
	
	
	public static void read()
	{
		
		 Session session = FactoryHelper.getConnection().openSession();
		 List<Yodlee_Event> eventList= session.createQuery("from Yodlee_Event").list();
		 for(Yodlee_Event event : eventList)
		 {
			 System.out.println(event.getName());
		 }
	}
    public static void main( String[] args )
    {
    	
    	/*Yodlee_Event event=new Yodlee_Event();
        event.setName("Devops Training");
        event.setEventDate(new Date(118,9,4));
        event.setLocation("Bangalore");
        
        addEvent(event);*/
    	//read();
    	//updateEvent(new Date(118,11,2),1);
    	//System.out.println(getEventById(1).getName());
    	//detachedObject();
    	Yodlee_Event event=new Yodlee_Event();
		event.setName("Advanced Java Training");
		event.setEventDate(new Date(118,9,1));
		event.setLocation("Bangalore");		
		
    	List<Yodlee_Employee> empList=new ArrayList<Yodlee_Employee>();
    	Yodlee_Employee emp =new Yodlee_Employee();
    	emp.setEmployeeId(56476);
    	emp.setName("Anoop");
        emp.setEvent(event);
    	empList.add(emp);
        event.setEmployeeList(empList);
        addEmployees(event);
        
    }
}
