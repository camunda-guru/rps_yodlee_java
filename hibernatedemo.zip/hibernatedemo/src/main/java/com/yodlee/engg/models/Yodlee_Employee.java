package com.yodlee.engg.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="YODLEE_EMPLOYEE")
public class Yodlee_Employee {
	@Id
	@Column(name="Employee_Id")
	private int employeeId;
	@Column(name="Employee_Name",nullable=false,length=50)
	private String name;
	@ManyToOne
	@JoinColumn(name="Event_Id")
	private Yodlee_Event event;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Yodlee_Event getEvent() {
		return event;
	}
	public void setEvent(Yodlee_Event event) {
		this.event = event;
	} 
	
	

}
