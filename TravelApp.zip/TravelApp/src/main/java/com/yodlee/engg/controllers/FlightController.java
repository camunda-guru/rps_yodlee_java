package com.yodlee.engg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yodlee.engg.models.Flight;
import com.yodlee.engg.services.FlightService;

@Controller
public class FlightController {
	@Autowired
	private FlightService flightService;
	@GetMapping(path="/")
	public String home(Model model)
	{
		//return "Welcome to Spring Boot Application";
		model.addAttribute("flightList", flightService.getAllFlights());
		return "home";
		
		
	}
	
	//@RequestMapping(path="/saveflight", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,
	//		produces=MediaType.APPLICATION_JSON_VALUE)
	
	@RequestMapping(path="/saveflight", method=RequestMethod.POST)
	public String saveFlight(@ModelAttribute Flight flight)
	{
		//return flightService.addFlight(flight);
		flightService.addFlight(flight);
		return "redirect:/";
	}
	
	@GetMapping(path="/getflights")
	public List<Flight> getFlights()
	{
		return flightService.getAllFlights();
	}
	
	@RequestMapping(path="/flightbyId/{code}", method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Flight saveFlight(@PathVariable int code)
	{
		 return flightService.getFlightById(code);
	}
	
	

}
