package com.cog.util;



import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.cog.entities.CTSMessage;
import com.cog.resources.HibernateUtil;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		
		System.out.println("retrieve from first level cache.....");
		CTSMessage ctsmessage= (CTSMessage) session.load(CTSMessage.class, 2);
		System.out.println(ctsmessage.getDescription());
		System.out.println("Before Clear"+session.contains(ctsmessage));
		session.evict(ctsmessage);
		System.out.println("After Clear"+session.contains(ctsmessage));
		System.out.println("retrieve from second level cache.....");
		Cache cache = sessionFactory.getCache();
		System.out.println(cache.containsEntity(CTSMessage.class, 2));
		ctsmessage=(CTSMessage) session.load(CTSMessage.class, 2);
		System.out.println(ctsmessage.getDescription());
		
		Transaction trans =session.beginTransaction();
		CTSMessage message=new CTSMessage();
		message.setDescription("Training Scheduled");
		try
		{
			session.save(message);
			session.getTransaction().commit();
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		
		session.close();
		
	}

}
