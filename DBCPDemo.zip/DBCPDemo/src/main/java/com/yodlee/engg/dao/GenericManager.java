package com.yodlee.engg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import com.yodlee.engg.helpers.DBHelper;
import com.yodlee.engg.models.Yodlee_User;

public class GenericManager<T> implements GenericDao<T>{
	private boolean status;
	private BasicDataSource ds;
	private Connection conn;
	private PreparedStatement pre;
	private Statement st;
	private ResultSet rs;
	@Override
	public boolean add(Object t) {
		// TODO Auto-generated method stub
		
		ds=DBHelper.getDBConnection();
		int recs=0;
		Yodlee_User user=null;
		try {
			conn=ds.getConnection();
			pre=conn.prepareStatement("insert into yodlee_user values(?,?,?)");
			if(t instanceof Yodlee_User)
			{
				user=(Yodlee_User) t;
			pre.setInt(1, user.getUserId());
			pre.setString(2,user.getName());
			pre.setString(3, user.getPassword());
			recs= pre.executeUpdate();
			}
			if(recs>0)
				status=true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			
		
		return status;
	
	}

	@Override
	public List getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
	
}
