package com.yodlee.engg.DBCPDemo;

import com.yodlee.engg.dao.GenericManager;
import com.yodlee.engg.models.Yodlee_User;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

		Yodlee_User user =new Yodlee_User();
		user.setName("Amit");
		user.setPassword("sharma");
		GenericManager<Yodlee_User> gm = new GenericManager<Yodlee_User>();
		System.out.println(gm.add(user)); 
		
    }
}
