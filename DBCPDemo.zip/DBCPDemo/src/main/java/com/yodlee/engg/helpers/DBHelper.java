package com.yodlee.engg.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.commons.dbcp2.BasicDataSource;

public class DBHelper {

    private static BasicDataSource ds;
	private static ResourceBundle rb;
	  private static String driver;
	    private static String url;
	    private static String username;
	    private static String password;
	public static BasicDataSource  getDBConnection()
	{
		
		rb=ResourceBundle.getBundle("com.yodlee.engg.resources/db");
    	driver=rb.getString("driver");
    	username=rb.getString("user");
    	password=rb.getString("password");
    	url=rb.getString("url");
		ds=new BasicDataSource();
		ds.setDriverClassName(driver);
		ds.setUrl(url);
		ds.setUsername(username);
		ds.setPassword(password);
		ds.setMaxIdle(5);
		ds.setMaxTotal(100);
		ds.setMaxWaitMillis(2000);
		return ds;
		
	}
	
}
