package com.yodlee.engg.dao;

import java.util.List;

public interface GenericDao<T> {
	
	boolean add(T t);
	List<T> getAll();

	

}
