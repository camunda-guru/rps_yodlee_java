package com.yodlee.engg.springcoreexample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yodlee.engg.models.Customer;

public class App 
{
    public static void main( String[] args )
    {
        
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("com/yodlee/engg/resources/spring-context.xml");
    	//IOC
    	Customer customer=(Customer) ctx.getBean("customer");
    	//read dependencies
    	System.out.println(customer.getCustomerId());    	
    	System.out.println(customer.getName());
    	System.out.println(customer.getAddress().getCity());
    	
    }
}
